package com.company;

public class Boss extends GameEntity {
    private String weaponAll;

    public String getWeaponAll() {
        return weaponAll;
    }

    public void setWeaponAll(String weaponAll) {
        this.weaponAll = weaponAll;
    }


}


